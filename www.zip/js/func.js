window.onload = function() {
outside.style.visibility='hidden';  

}


function visivel()
{
    document.getElementById("outside").style.visibility = "";
}