<?php
mysql_connect("mysql.hostinger.com.br", "u606746288_luis", "l0u7i2") or die (mysql_error ());

mysql_select_db("u606746288_imei") or die(mysql_error());


strSQL = "INSERT INTO contatos(nome) values('" . $_POST["nome"] . "')"

?>